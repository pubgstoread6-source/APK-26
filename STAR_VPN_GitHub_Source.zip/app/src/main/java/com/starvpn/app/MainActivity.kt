package com.starvpn.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.config.Config
import com.wireguard.android.backend.Tunnel
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val pickRequest = 4101
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var backend: Backend
    private lateinit var status: TextView
    private lateinit var profileName: TextView
    private lateinit var connectButton: Button
    private var wgConfig: Config? = null
    private var importedName: String = "No profile imported"
    private var connected = false

    private val tunnel = object : Tunnel {
        override fun getName(): String = "star-vpn"
        override fun onStateChange(newState: Tunnel.State) {
            runOnUiThread {
                connected = newState == Tunnel.State.UP
                status.text = if (connected) "WIREGUARD CONNECTED" else "DISCONNECTED"
                connectButton.text = if (connected) "DISCONNECT" else "CONNECT"
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        backend = GoBackend(this)
        buildUi()
    }

    private fun buildUi() {
        val bg = 0xFF07110D.toInt()
        val green = 0xFF27E58B.toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(bg)
        }
        val logo = TextView(this).apply {
            text = "★  STAR VPN"
            textSize = 30f
            setTextColor(green)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "SECURE • PRIVATE • SIMPLE"
            textSize = 12f
            setTextColor(0xFF9DB5A8.toInt())
            gravity = Gravity.CENTER
        }
        profileName = TextView(this).apply {
            text = importedName
            textSize = 16f
            setTextColor(-1)
            gravity = Gravity.CENTER
            setPadding(0, 36, 0, 16)
        }
        status = TextView(this).apply {
            text = "DISCONNECTED"
            textSize = 14f
            setTextColor(green)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        val importWg = makeButton("IMPORT WIREGUARD (.conf)", green)
        importWg.setOnClickListener { chooseFile("application/octet-stream", "conf") }
        val importOvpn = makeButton("IMPORT OPENVPN (.ovpn)", green)
        importOvpn.setOnClickListener { chooseFile("*/*", "ovpn") }
        connectButton = makeButton("CONNECT", green)
        connectButton.setOnClickListener { toggleWireGuard() }
        val note = TextView(this).apply {
            text = "WireGuard connects inside STAR VPN. OpenVPN profiles are handed to the installed OpenVPN for Android client for the actual tunnel."
            textSize = 12f
            setTextColor(0xFF9DB5A8.toInt())
            gravity = Gravity.CENTER
            setPadding(8, 30, 8, 0)
        }
        layout.addView(logo, matchWrap())
        layout.addView(subtitle, matchWrap())
        layout.addView(profileName, matchWrap())
        layout.addView(status, matchWrap())
        layout.addView(importWg, buttonParams())
        layout.addView(importOvpn, buttonParams())
        layout.addView(connectButton, buttonParams())
        layout.addView(note, matchWrap())
        setContentView(layout)
    }

    private fun makeButton(label: String, color: Int) = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(0xFF06110B.toInt())
        setBackgroundColor(color)
        isAllCaps = false
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    )
    private fun buttonParams() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 8, 0, 8) }

    private fun chooseFile(mime: String, extension: String) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                if (extension == "conf") "text/plain" else "application/x-openvpn-profile",
                "application/octet-stream", "text/plain"
            ))
        }
        startActivityForResult(intent, pickRequest + if (extension == "ovpn") 1 else 0)
    }


    @Deprecated("Use Activity Result API in production")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 4200) {
            if (resultCode == RESULT_OK && pendingConnect) wgConfig?.let { connect(it) }
            pendingConnect = false
            return
        }
        if (resultCode != RESULT_OK || data?.data == null) return
        if (requestCode == pickRequest) importWireGuard(data.data!!)
        else if (requestCode == pickRequest + 1) handoffOpenVpn(data.data!!)
    }

    private fun readUri(uri: Uri): String =
        contentResolver.openInputStream(uri)?.use { input ->
            BufferedReader(InputStreamReader(input)).readText()
        } ?: error("Cannot read selected file")

    private fun importWireGuard(uri: Uri) {
        try {
            val text = readUri(uri)
            wgConfig = Config.parse(text.byteInputStream())
            importedName = uri.lastPathSegment?.substringAfterLast('/') ?: "WireGuard profile"
            profileName.text = importedName
            status.text = "WIREGUARD PROFILE READY"
            Toast.makeText(this, "WireGuard profile imported", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Invalid .conf: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun handoffOpenVpn(uri: Uri) {
        try {
            // OpenVPN for Android exposes an import activity for .ovpn files.
            val view = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/x-openvpn-profile")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(view, "Import profile into OpenVPN")
            startActivity(chooser)
            importedName = uri.lastPathSegment?.substringAfterLast('/') ?: "OpenVPN profile"
            profileName.text = importedName
            status.text = "OPENVPN PROFILE SENT TO CLIENT"
            Toast.makeText(this, "Save the profile in OpenVPN, then connect there.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Install OpenVPN for Android to use .ovpn profiles.", Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleWireGuard() {
        val config = wgConfig
        if (config == null) {
            Toast.makeText(this, "First import a WireGuard .conf file", Toast.LENGTH_SHORT).show()
            return
        }
        if (connected) {
            executor.execute {
                try { backend.setState(tunnel, Tunnel.State.DOWN, null) }
                catch (e: Exception) { showError(e) }
            }
            return
        }
        val permission = GoBackend.VpnService.prepare(this)
        if (permission != null) {
            startActivityForResult(permission, 4200)
            pendingConnect = true
        } else connect(config)
    }

    private var pendingConnect = false

    private fun connect(config: Config) {
        status.text = "CONNECTING…"
        executor.execute {
            try { backend.setState(tunnel, Tunnel.State.UP, config) }
            catch (e: Exception) { showError(e) }
        }
    }

    private fun showError(e: Exception) {
        runOnUiThread {
            status.text = "CONNECTION FAILED"
            Toast.makeText(this, e.message ?: "VPN error", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        executor.shutdown()
        super.onDestroy()
    }
}
