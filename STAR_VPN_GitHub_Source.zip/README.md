# STAR VPN (Android)

Android Studio starter project for STAR VPN.

- WireGuard `.conf`: real in-app tunnel using the official WireGuard Android tunnel library.
- OpenVPN `.ovpn`: imports by handing the selected file to OpenVPN for Android. The companion client must be installed and the user completes the profile import/connection there. OpenVPN is not yet embedded in-process in this starter.

Open in Android Studio, install SDK 35, sync Gradle, connect an Android device, and Run. A valid working VPN configuration and reachable VPN server are required.

This project has not been compiled or device-tested in this environment. See README_FA.md for Persian setup notes.
